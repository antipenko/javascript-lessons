$(document).foundation();

